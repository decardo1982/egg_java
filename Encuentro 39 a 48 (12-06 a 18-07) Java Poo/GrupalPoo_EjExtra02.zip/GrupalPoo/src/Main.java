import ejercicio1.Vehiculo;
import ejercicio2.FiguraService;

public class Main {
    public static void main(String[] args) {


//        Vehiculo auto = new Vehiculo("Ford","Fiesta",2007,"automovil");
//        Vehiculo moto = new Vehiculo("Zanella","Hot 90",2003,"motocicleta");
//        Vehiculo bici = new Vehiculo("Vairo","Mohave",2022,"bicicleta");
//
//        auto.moverse(1);
//        moto.moverse(1);
//        bici.moverse(1);
//
//        auto.frenar();
//        moto.frenar();
//        bici.frenar();

        FiguraService calculadora = new FiguraService();

        calculadora.iniciar();

    }
}