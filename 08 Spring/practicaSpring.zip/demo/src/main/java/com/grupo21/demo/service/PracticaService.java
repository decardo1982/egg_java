package com.grupo21.demo.service;

import com.grupo21.demo.entity.Practica;
import com.grupo21.demo.entity.PracticaDto;
import com.grupo21.demo.repository.PracticaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
public class PracticaService {
    @Autowired
    private PracticaRepository practicaRepository;

    public Practica guardarPractica(PracticaDto practicaDto){
        Practica practica = new Practica();
        practica.setNombre(practicaDto.getNombre());
        practica.setApellido(practicaDto.getApellido());

        return practicaRepository.save(practica);
    }

    public List<PracticaDto> allPracticas(){
        List<Practica> listaPracticas = practicaRepository.findAll();
        List<PracticaDto> listaPracticasDto = new ArrayList<>();

        for(Practica practica:listaPracticas){
            PracticaDto practicaDto = new PracticaDto();
            practicaDto.setNombre(practica.getNombre());
            practicaDto.setApellido(practica.getApellido());
            listaPracticasDto.add(practicaDto);
        }

        return listaPracticasDto;
    }

    public List<Practica> todaLaData(){
        return practicaRepository.findAll();
    }

    public void borrarPractica(Long id){
        practicaRepository.deleteById(id);
    }
}
