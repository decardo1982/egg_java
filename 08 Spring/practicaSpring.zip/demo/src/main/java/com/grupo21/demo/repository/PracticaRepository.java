package com.grupo21.demo.repository;

import com.grupo21.demo.entity.Practica;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PracticaRepository extends JpaRepository<Practica,Long> {

}
