package com.grupo21.demo.controller;


import com.grupo21.demo.entity.Practica;
import com.grupo21.demo.entity.PracticaDto;
import com.grupo21.demo.service.PracticaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/practica")
@RequiredArgsConstructor
public class PracticaController {

    private final PracticaService practicaService;



    @PostMapping("")
    public Practica guardarPractica(@RequestBody PracticaDto practicaDto){
       return practicaService.guardarPractica(practicaDto);
    }

   @GetMapping("")
    public List<PracticaDto> traerTodasLasPractias(){
        return practicaService.allPracticas();
   }

    @GetMapping("/todo")
    public List<Practica> traerTodasLasPractiasConContrasenia(){
        return practicaService.todaLaData();
    }

   @DeleteMapping("/{id}")
    public void eliminarPractica(@PathVariable Long id){
        practicaService.borrarPractica(id);
   }
}
