package ejerciciosaprendizaje02;

import servicios.TiendaServicio;

public class EjerciciosAprendizaje02 {

    public static void main(String[] args) {
        TiendaServicio tiendaServicio = new TiendaServicio();
        tiendaServicio.iniciarPrograma();
    }
    
}
