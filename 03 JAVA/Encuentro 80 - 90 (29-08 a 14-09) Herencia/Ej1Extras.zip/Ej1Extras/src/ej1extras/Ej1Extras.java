
package ej1extras;

import Services.AlquilerServices;

public class Ej1Extras {

    public static void main(String[] args) {
        AlquilerServices alquilerS = new AlquilerServices();
        alquilerS.crearAlquiler();
        alquilerS.calcularMonto();
    }
    
}
