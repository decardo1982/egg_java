package Entidades;

/*
blanco, negro, rojo, azul y gris
 */

public enum Colores {
    BLANCO, NEGRO, ROJO, AZUL, GRIS;
}
