/*

 */
package herencia2.entities;

import herencia2.enumeraciones.consumoEnergetico;
import herencia2.enumeraciones.enumColor;

/**
 *
 * @author carol
 */
public class Electrodomestico {
    
    protected Double precio;
    protected enumColor color;
    protected consumoEnergetico consumo;
    protected Double peso;

    public Electrodomestico() {
    }

    public Electrodomestico(Double precio, enumColor color, consumoEnergetico consumo, Double peso) {
        this.precio = precio;
        this.color = color;
        this.consumo = consumo;
        this.peso = peso;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public enumColor getColor() {
        return color;
    }

    public void setColor(enumColor color) {
        this.color = color;
    }

    public consumoEnergetico getConsumo() {
        return consumo;
    }

    public void setConsumo(consumoEnergetico consumo) {
        this.consumo = consumo;
    }

    public Double getPeso() {
        return peso;
    }

    public void setPeso(Double peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Electrodomestico{" + "precio=" + precio + ", color=" + color + ", consumo=" + consumo + ", peso=" + peso + '}';
    }
    
}
