import ejercicioExtra3.Ahorcado;

public class Main {
    public static void main(String[] args) {


        Ahorcado a1 = new Ahorcado();

        a1.juego();
    }
}